#ifndef VIDEO_H
#define VIDEO_H

class Video
{	public:
		virtual void updateVideo(int pos) = 0;
};

#endif
